#ifndef __SYSFS_H__
#define __SYSFS_H__

const char *sysfs_find_mountpoint(void);

#endif /* __DEBUGFS_H__ */
