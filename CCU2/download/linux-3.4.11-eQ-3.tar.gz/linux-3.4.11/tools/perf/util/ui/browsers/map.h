#ifndef _PERF_UI_MAP_BROWSER_H_
#define _PERF_UI_MAP_BROWSER_H_ 1
struct map;

int map__browse(struct map *self);
#endif /* _PERF_UI_MAP_BROWSER_H_ */
